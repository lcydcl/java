<?php

namespace app\common\model;

use think\Model;

/**
 * 消费券模型
 */
class Coupons extends Common
{
	 
}