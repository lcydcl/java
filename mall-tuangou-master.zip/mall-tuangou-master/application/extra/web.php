<?php
/**
 * 站点配置
 */
return [
    'web_name' => 'MALL团购网',  // 网站名称
    'web_keywords' => 'MALL团购网,团购网,O2O平台,电子商城,团购,商城,电子商城', // 关键字
    'web_description' => '线上交易、线下消费的O2O平台——MALL团购网', // 描述
    'web_key' => md5('cd3e9860c4d1b242495a00edb011aba3'), // 站点key
    'web_defult_city' => 'tianjin', // 默认显示的城市名（英文标识）
];