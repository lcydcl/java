<?php
//配置文件
return [
    /**
     * API模块统一返回JSON数据
     */
    'default_return_type' => 'json',
    'default_ajax_type' => 'json',
];