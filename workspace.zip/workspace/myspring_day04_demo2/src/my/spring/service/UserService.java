package my.spring.service;

import org.springframework.transaction.annotation.Transactional;

import my.spring.dao.UserDao;

@Transactional
public class UserService {

	private UserDao userDao;
	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}

	public void add(){
		userDao.add();
	}
}
