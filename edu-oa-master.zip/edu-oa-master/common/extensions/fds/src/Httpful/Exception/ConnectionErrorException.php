<?php 

namespace Httpful\Exception;

class ConnectionErrorException extends \Exception 
{
}