<?php

require_once(__DIR__ . '/src/Httpful/Bootstrap.php');
\Httpful\Bootstrap::init();

require_once(__DIR__ . '/src/FDS/Bootstrap.php');
\FDS\Bootstrap::init();
